package com.example.quoteoftheday;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvQuote, tvAuthor;
    private ImageView imageViewBackground;
    private Switch switchTheme;
    private Button btnNewQuote;
    private FrameLayout rootLayout;

    private final List<String> quotes = Arrays.asList(
            "Be yourself; everyone else is already taken. — Oscar Wilde",
            "The only limit to our realization of tomorrow is our doubts of today. — Franklin D. Roosevelt",
            "In the middle of every difficulty lies opportunity. — Albert Einstein",
            "Life is what happens when you're busy making other plans. — John Lennon",
            "Do what you can, with what you have, where you are. — Theodore Roosevelt"
    );

    private final List<String> images = Arrays.asList(
            "nature", "mountain", "forest", "ocean", "sky", "sunset"
    );

    private final Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvQuote = findViewById(R.id.tvQuote);
        tvAuthor = findViewById(R.id.tvAuthor);
        imageViewBackground = findViewById(R.id.imgQuote);
        switchTheme = findViewById(R.id.switchTheme);
        btnNewQuote = findViewById(R.id.btnNewQuote);
        rootLayout = findViewById(R.id.rootLayout);

        // Style (keep simple)
        tvQuote.setTextSize(24);
        tvAuthor.setTextSize(18);
        btnNewQuote.setAllCaps(false);

        loadNewQuote();

        switchTheme.setOnCheckedChangeListener((b, checked) -> {
            if (checked) {
                rootLayout.setBackgroundColor(Color.BLACK);
                tvQuote.setTextColor(Color.WHITE);
                tvAuthor.setTextColor(Color.WHITE);
            } else {
                rootLayout.setBackgroundColor(Color.WHITE);
                tvQuote.setTextColor(Color.BLACK);
                tvAuthor.setTextColor(Color.BLACK);
            }
        });

        btnNewQuote.setOnClickListener(v -> {
            loadNewQuote();
            fadeViews();
        });
    }

    private void loadNewQuote() {

        String randomQuote = quotes.get(random.nextInt(quotes.size()));

        if (randomQuote.contains("—")) {
            String[] parts = randomQuote.split("—");
            tvQuote.setText(parts[0].trim());
            tvAuthor.setText("— " + parts[1].trim());
        } else {
            tvQuote.setText(randomQuote);
            tvAuthor.setText("");
        }

        String keyword = images.get(random.nextInt(images.size()));
        String url = "https://picsum.photos/800/600?random"; // 100% works

        Log.d("IMG_URL", url);

        Glide.with(this)
                .load(url)
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .into(imageViewBackground);

        Toast.makeText(this, "New Quote Loaded!", Toast.LENGTH_SHORT).show();
    }

    private void fadeViews() {
        tvQuote.setAlpha(0f);
        tvQuote.animate().alpha(1f).setDuration(400).start();

        tvAuthor.setAlpha(0f);
        tvAuthor.animate().alpha(1f).setDuration(400).start();

        imageViewBackground.setAlpha(0f);
        imageViewBackground.animate().alpha(1f).setDuration(500).start();
    }
}
