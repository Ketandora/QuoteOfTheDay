package com.example.quoteoftheday;

import android.content.Context;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QuoteManager {

    public static void fetchQuote(Context context, QuoteCallback callback) {

        QuoteApi api = RetrofitClient.getClient().create(QuoteApi.class);

        api.getRandomQuote().enqueue(new Callback<QuoteResponse>() {
            @Override
            public void onResponse(Call<QuoteResponse> call, Response<QuoteResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onQuoteReceived(
                            response.body().getContent(),
                            response.body().getAuthor()
                    );
                } else {
                    Toast.makeText(context, "Failed to get quote", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<QuoteResponse> call, Throwable t) {
                Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public interface QuoteCallback {
        void onQuoteReceived(String quote, String author);
    }
}
